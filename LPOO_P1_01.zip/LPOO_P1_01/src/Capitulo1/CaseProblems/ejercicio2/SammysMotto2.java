package Capitulo1.CaseProblems.ejercicio2;

public class SammysMotto2 {

	public static void main(String[] args) {
		System.out.println("SsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSs");
		System.out.println("Ss Sammy’s makes it fun in the sun. Ss");
		System.out.println("SsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSs");
	}

}
