package Capitulo1.ProgrammingExercises.ejercicio10;

public class Comments {

	public static void main(String[] args) {
		
		//“Program comments are nonexecuting statements you add to a file for the purpose of documentation.”
		
		/* “Program comments are nonexecuting statements you add to a file for the purpose of
documentation.”*/
		
		/** “Program comments are nonexecuting statements you add to a file for the purpose of
documentation.” */
		
		System.out.println("“Program comments are nonexecuting statements you add to a file for the purpose of documentation.”");
	}

}
