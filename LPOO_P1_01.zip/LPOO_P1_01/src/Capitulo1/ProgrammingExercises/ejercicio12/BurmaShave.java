package Capitulo1.ProgrammingExercises.ejercicio12;

import javax.swing.JOptionPane;

public class BurmaShave {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, "Don't lose");
		JOptionPane.showMessageDialog(null, "Your head");
		JOptionPane.showMessageDialog(null, "To gain a minute");
		JOptionPane.showMessageDialog(null, "You need your head");
		JOptionPane.showMessageDialog(null, "Your brains are in it");
		JOptionPane.showMessageDialog(null, "Burma-Shave");
		
	}

}
