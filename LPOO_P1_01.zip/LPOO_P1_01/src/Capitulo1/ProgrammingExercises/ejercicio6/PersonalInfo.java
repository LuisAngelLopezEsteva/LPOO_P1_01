package Capitulo1.ProgrammingExercises.ejercicio6;

public class PersonalInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("NOmbre: Luis Angel Lopez Esteva");
		System.out.println("Email:  lukaz.code.luna@gmail.com");
		System.out.println("Number phone: 971-185-98-12");
	}

}
