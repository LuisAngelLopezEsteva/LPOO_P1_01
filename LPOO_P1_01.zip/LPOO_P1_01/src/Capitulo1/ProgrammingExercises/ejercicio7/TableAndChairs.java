package Capitulo1.ProgrammingExercises.ejercicio7;

public class TableAndChairs {
//	Write, compile, and test a class that displays the word “Java” 
//	on the screen. Compose each large letter using the appropriate 
//	character, as in the following example:

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("X                         X\n" + 
			               "X                         X\n" + 
				           "X        XXXXXXXXXX       X\n" + 
				           "XXXXX	 X        X   XXXXX\n" + 
				           "X   X	 X        X   X   X\n" + 
				           "X   X    X        X   X   X");
	}

}
