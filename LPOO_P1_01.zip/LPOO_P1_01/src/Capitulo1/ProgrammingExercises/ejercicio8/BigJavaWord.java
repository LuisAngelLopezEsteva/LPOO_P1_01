package Capitulo1.ProgrammingExercises.ejercicio8;

public class BigJavaWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("         J          A     V       V    A\n" + 
						   "         J         A A     V     V    A A\n" + 
						   "         J        A   A     V   V    A   A\n" + 
						   "    J    J       AAAAAAA     V V    AAAAAAA\n" + 
						   "    JJJJJJ      A       A     V    A       A\n" );

	}

}
