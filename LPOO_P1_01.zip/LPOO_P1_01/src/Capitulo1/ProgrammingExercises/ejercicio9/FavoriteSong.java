package Capitulo1.ProgrammingExercises.ejercicio9;

public class FavoriteSong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("My favorite song is: Feel Invincible\n\n");
		System.out.println("Target on my back lone survivor lasts\n" + 
				"They got me in their sights\n" + 
				"No surrender no\n" + 
				"Trigger fingers go\n" + 
				"Living the dangerous life\n" + 
				"Hey, hey, hey everyday when I wake\n" + 
				"I'm trying to get up, they're knocking me down\n" + 
				"Chewing me up, spitting me out\n" + 
				"Hey, hey, hey when I need to be saved\n" + 
				"You're making me strong, you're making me stand\n" + 
				"Never will fall, never will end\n" + 
				"Shot like a rocket up into the sky\n" + 
				"Nothing could stop me tonight\n" + 
				"You make me feel invincible\n" + 
				"Earthquake, powerful\n" + 
				"Just like a tidal wave\n" + 
				"You make me brave\n" + 
				"You're my titanium\n" + 
				"Fight song, raising up\n" + 
				"Like a roar of victory in a stadium\n" + 
				"Who can touch me 'cause I'm (I'm made of fire)\n" + 
				"Who can stop me tonight (I'm hard wired)\n" + 
				"You make me feel invincible\n" + 
				"I feel, I feel it\n" + 
				"Invincible\n" + 
				"I feel, I feel it\n" + 
				"Invincible\n" + 
				"Here we go againi will not give in\n" + 
				"I've got a reason to fight\n" + 
				"Every day we choose\n" + 
				"We might win or lose\n" + 
				"This is the dangerous life\n" + 
				"Hey, hey, hey everyday when I wake\n" + 
				"They say that I'm gone; they say that they've won\n" + 
				"The bell has been rung, it's over and done\n" + 
				"Hey, hey, hey when I need to be saved\n" + 
				"They counting me out, but this is my round\n" + 
				"(You in my corner look at me now)\n" + 
				"Shot like a rocket up into the sky\n" + 
				"Nothing could stop me tonight\n" + 
				"You make me feel invincible\n" + 
				"Earthquake, powerful\n" + 
				"Just like a tidal wave\n" + 
				"You make me brave\n" + 
				"You're my titanium\n" + 
				"Fight song, raising up\n" + 
				"Like a roar of victory in a stadium\n" + 
				"Who can touch me 'cause I'm (I'm made of fire)\n" + 
				"Who can stop me tonight (I'm hard wired)\n" + 
				"You make me feel invincible\n" + 
				"I feel, I feel it\n" + 
				"Invincible\n" + 
				"I feel, I feel it\n" + 
				"Invincible\n" + 
				"You make me feel invincible\n" + 
				"You make me feel invincible\n" + 
				"Shot like a rocket up into the sky\n" + 
				"Not gonna stop, invincible\n" + 
				"You make me feel invincible\n" + 
				"Earthquake, powerful\n" + 
				"Just like a tidal wave\n" + 
				"You make me brave\n" + 
				"You're my titanium\n" + 
				"Fight song, raising up\n" + 
				"Like a roar of victory in a stadium\n" + 
				"You make me feel invincible\n" + 
				"Earthquake, powerful\n" + 
				"Just like a tidal wave\n" + 
				"You make me brave\n" + 
				"You're my titanium\n" + 
				"Fight song, raising up\n" + 
				"Like a roar of victory in a stadium\n" + 
				"Who can touch me 'cause I'm (I'm made of fire)\n" + 
				"Who can stop me tonight (I'm hard wired)\n" + 
				"You make me feel invincible\n" + 
				"I feel, I feel it\n" + 
				"Invincible\n" + 
				"I feel, I feel it\n" + 
				"Invincible\n" + 
				"");
	}

}
