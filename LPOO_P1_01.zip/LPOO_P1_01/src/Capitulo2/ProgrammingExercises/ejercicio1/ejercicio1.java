package Capitulo2.ProgrammingExercises.ejercicio1;

public class ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" What is the numeric value of each of the following expressions as evaluated by Java?");
		 		
		System.out.println("a. 3+7*2        	= "+(3+7*2 ) );
		System.out.println("b. 18 / 3 + 4  		= " +(18 / 3 + 4));
		System.out.println("c. 9 / 3 + 12 / 4   = " +(9 / 3 + 12 / 4));
		System.out.println("d. 15 / 2           = " +( 15 / 2  ));
		System.out.println("e. 14 / 3			= "+(14 / 3));
		System.out.println("f. 29 / 10			= "+ (29 / 10));
		System.out.println("g. 14 % 2 			="+(14 % 2));
		System.out.println("h. 15 % 2			=" +(15 % 2));
		System.out.println("i. 31 % 7			="+(31 % 7));
		System.out.println("j. 6%4+1			="+(6%4+1));
		System.out.println("k. (5 + 6) * 3		="+((5 + 6) * 3));
		System.out.println("l. 25 / (3 + 2)		="+(25 / (3 + 2)));
		System.out.println("m. 13 % 15			="+(13 % 15));
		
	}

}
