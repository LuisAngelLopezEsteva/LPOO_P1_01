package Capitulo2.ProgrammingExercises.ejercicio2;

public class ejercicio2 {

	public static void main(String[] args) {
		System.out.println("2. What is the value of each of the following Boolean expressions?");
		System.out.println("a. 5<8\n" + 
				" b. 4 <= 9     :" +( 4 <= 9) +" \n" + 
				" c. 3 == 4     :" +( 3 == 4) +" \n" +  
				" d. 12 >= 12   :" +( 12>= 12) +" \n" + 
				" e. 3 + 4 == 8 :"+( 3 + 4 == 8) +" \n" + 
				" f. 7<9 – 2    :" + (7<9 - 2 )  +" \n" +
				" g. 5 != 5     :" + (5 != 5 )  +" \n" + 
				" h. 15 != 3 * 5   :" + (15 != 3 * 5  )  +" \n" + 
				" i. 9 != –9       :" + ( 9 != -9 )      +" \n" + 
				" j. 3 + 5 * 2 == 16  :" + (3 + 5 * 2 == 16 )  +" \n" + 
				"");
	}

}
