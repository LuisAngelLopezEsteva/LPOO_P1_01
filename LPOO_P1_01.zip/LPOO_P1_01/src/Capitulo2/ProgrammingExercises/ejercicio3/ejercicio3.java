package Capitulo2.ProgrammingExercises.ejercicio3;

public class ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Choose the best data type for each of the following so that any reasonable value is\n "
				+ "accommodated but no memory storage is wasted. Give an example of a typical value that would be\n"
				+ " held by the variable, and explain why you chose the type you did.\n");
		
		System.out.println("a.  the number of siblings you have: \n"
				+ "R:byte , porque el alcance me basta\n");
		System.out.println("\nb. your final grade in this class: \n"  
				+ "R:byte , porque el alcance me basta\n");
		
		System.out.println("\nc. the population of Earth :\n"
				+ "int , porque el alcance es el necesario ");
		System.out.println("\nd. the population of a U.S. county: \n"  
				+ "int , porque el alcance es el necesario ");
		
		System.out.println("\ne. the number of passengers on a bus \n"  
				+ "R:byte , porque en un autobus nunca pasan de 150 personas\n");
	
	}

}
