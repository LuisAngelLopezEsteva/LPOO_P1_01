package Capitulo2.ProgrammingExercises.ejercicio4;

public class MilesToFeet {

	public static void main(String[] args) {
		final int miletofeet = 5280;
		double distancia = 10 ;
		// TODO Auto-generated method stub
		System.out.println("La distancia hasta la casa de mi tío es de " + distancia + " millas o "
				+ (distancia * miletofeet) + " pies. ");
	}

}
