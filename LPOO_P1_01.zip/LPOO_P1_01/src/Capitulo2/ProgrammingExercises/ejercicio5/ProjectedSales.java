package Capitulo2.ProgrammingExercises.ejercicio5;

public class ProjectedSales {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double incremento = 1.1;
		double norte=4000;
		double sur=5500;
		
		System.out.println("las ventas proyectadas del próximo año para división Norte: "+ (norte*incremento));
		System.out.println("las ventas proyectadas del próximo año para división Sur:  "+(sur*incremento));
	}

}
