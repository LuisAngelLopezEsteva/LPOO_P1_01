package Capitulo2.ProgrammingExercises.ejercicio7;

public class Initials {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String iniciales = "L.A.L.E";
		System.out.println(iniciales);
	}

}
