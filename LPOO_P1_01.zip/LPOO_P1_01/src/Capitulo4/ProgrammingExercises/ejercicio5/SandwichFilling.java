package Capitulo4.ProgrammingExercises.ejercicio5;

public class SandwichFilling {

	public SandwichFilling(String typeFilling, int calorias) {
		this.typeFilling = typeFilling;
		this.calorias = calorias;

	}

	private String typeFilling;
	private int calorias;

	public String getTypeFilling() {
		return typeFilling;
	}

	public int getCalorias() {
		return calorias;
	}

}
